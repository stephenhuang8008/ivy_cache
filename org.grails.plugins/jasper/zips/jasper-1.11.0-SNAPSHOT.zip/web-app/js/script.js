$(document).ready(function() {
  $('h1').text('Page optimized by Wro4j Grails Plugin');
})
