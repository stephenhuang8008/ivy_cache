class DbdocUrlMappings {
	static mappings = {
		"/dbdoc/$section?/$filename?/$table?/$column?"(controller: 'dbdoc')
	}
}
